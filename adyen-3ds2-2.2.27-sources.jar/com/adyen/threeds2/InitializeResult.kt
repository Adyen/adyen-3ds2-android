package com.adyen.threeds2

/**
 * An object that represents the outcome of the initializing the [ThreeDS2Service].
 * Its values can be the following:
 * * [Completed][InitializeResult.Success]: the initialization is successful.
 * * [Failure][InitializeResult.Failure]: An internal error occurred during initialization.
 */
public sealed interface InitializeResult {

    /**
     * Initialization process is completed successfully.
     */
    public data object Success : InitializeResult

    /**
     * An internal error occurred during the initialization process.
     *
     * @param transactionStatus The [Transaction] status required for Adyen to identify the final
     * status of a transaction.
     * @param additionalDetails Details required for Adyen to troubleshoot the error.
     */
    public class Failure(
        public val transactionStatus: String = DEFAULT_ERROR_TRANSACTION_STATUS,
        public val additionalDetails: String,
    ) : InitializeResult
}

private const val DEFAULT_ERROR_TRANSACTION_STATUS = "U"
