package com.adyen.threeds2

/**
 * An object that represents the outcome of creating a transaction.
 * Returned by [ThreeDS2Service.createTransaction].
 * Its values can be the following:
 * * [Completed][TransactionResult.Success]: the initialization is successful.
 * * [Failure][TransactionResult.Failure]: An internal error occurred during initialization.
 */
public sealed interface TransactionResult {

    /**
     * Initialization process is completed successfully.
     */
    public class Success(public val transaction: Transaction) : TransactionResult

    /**
     * An internal error occurred during the transaction creation process.
     *
     * @param transactionStatus The [Transaction] status required for Adyen to identify the final
     * status of a transaction.
     * @param additionalDetails Details required for Adyen to troubleshoot the error.
     */
    public class Failure(
        public val transactionStatus: String = DEFAULT_ERROR_TRANSACTION_STATUS,
        public val additionalDetails: String,
    ) : TransactionResult
}

private const val DEFAULT_ERROR_TRANSACTION_STATUS = "U"
