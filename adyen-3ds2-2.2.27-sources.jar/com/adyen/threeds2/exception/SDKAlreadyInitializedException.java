/*
 * Copyright (C) 2018 Adyen N.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.adyen.threeds2.exception;

/**
 * This class represents an exception that is thrown if the 3DS SDK instance has already been initialized.
 * <p>
 * Created by Ran Haveshush on 24/08/2018.
 *
 * @deprecated This exception is not thrown anymore. It can be safely removed.
 */
@Deprecated
public final class SDKAlreadyInitializedException extends Exception {
    private static final long serialVersionUID = -4627649881838637045L;

    public SDKAlreadyInitializedException() {
        super(null, null);
    }
}
